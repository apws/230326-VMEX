/*
 * Marc 'BlackJack' Rintsch, 06.03.2001
 *
 * unsigned int cbm_load(const char* name,
 *                       unsigned char device,
 *                       const unsigned char* data);
 */
#include <stdio.h>
#include <cbm.h>
#include "membank128.h"
#include "simpleio.h"

/* loads file "name" from given device to given address or to the load address
 * of the file if "data" is 0
 */
unsigned int bank1_cbm_load(const char* name, unsigned char device, void* data)
{
	/* LFN is set to 0 but it's not needed for loading.
	 * (BASIC V2 sets it to the value of the SA for LOAD) */
	static unsigned int i;
//printscr (name);
//putchar ('1');
	cbm_k_setbnk (1, 0);
	// __asm__ (
		// "\tlda\t#1\n"
		// "\tsta\ttmp4\n"
		// "\tldx\t#0\n"
		// //"\tstx\ttmp4\n"
		// "\tlda\t#$68\n"
		// "\tjsr\tcallkernal\n"
		// );
	cbm_k_setlfs(0, device, data == 0);
	/*__asm__ (
		"\tlda\t#0\n"
		"\tsta\ttmp4\n"
		//"\tldx\t%o\n"
		"\tldy\t#%o\n"
		"\tlda\t(sp),y\n"
		"\ttax\n"
		"\tldy\t#%o\n"
		"\tlda\t(sp),y\n"
		"\tiny\n"
		"\tora\t(sp),y\n"
		"\tbne\t@l2\n"
		"\tldy\t#1\n"
		"\tbne\t@l3\n"
		"@l2:\n"
		"\tldy\t#0\n"
		"@l3:\n"
		"\tlda\t#<SETLFS\n"
		"\tjsr\tcallkernal\n",
		device, data
		);*/
	cbm_k_setnam(name);
//putchar ('2');

	i=(cbm_k_load(0, (unsigned int)data) - (unsigned int)data);
//printf ("ST: %d\n", cbm_k_readst());
	//return (cbm_k_load(0, (unsigned int)data));
	//i=(cbm_k_load(0, (unsigned int)data));
	//cbm_k_setbnk (0, 0);
	__asm__ (
		"\tldx\t#0\n"
		"\tstx\ttmp4\n"
		"\tlda\t#$68\n"
		"\tjsr\tcallkernal\n"
		);
//putchar ('3');
//putchar (13);
	return i;
}
