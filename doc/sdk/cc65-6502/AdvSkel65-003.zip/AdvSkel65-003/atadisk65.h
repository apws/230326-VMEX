/***********************************************************************
 * 
 * Individual header for the cc65 compiler.
 *
 * The template for this file was created by TempC Module Creator by
 * Joseph Rose.  This template can be used in your programs, provided
 * you mention TempC in your software's documentation.  If this source
 * code is distributed, this copyright must be included in the file.
 *
 ***********************************************************************/

#ifndef __ATARI_CIOX_ALL_H
#define __ATARI_CIOX_ALL_H

unsigned char __fastcall__ cio_open (unsigned char channel, char* filename, unsigned char dir);
unsigned char __fastcall__ cio_close (unsigned char channel);
unsigned char __fastcall__ cio_read (unsigned char channel, unsigned char* buffer, unsigned len);
unsigned char __fastcall__ cio_load (unsigned char channel, char* filename, unsigned char * buffer, unsigned len);

#endif

