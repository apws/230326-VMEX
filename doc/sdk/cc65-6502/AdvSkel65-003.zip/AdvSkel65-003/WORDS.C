/**************************************************
 *
 *   Contains the vocabulary and responses of
 *   Adventures on Planet Smir III, 1
 *
 **************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <errno.h>
#include <ctype.h>

#include "aconst.h"
#include "words.h"
#include "stores.h"
#include "rooms.h"
#include "player.h"
#include "input.h"

//Same as in player.c.
#ifdef __CBM__
#include "simpleio.h"
#elif defined __ATARIXL__
#include "atasimpleio.h"
#elif defined __APPLE2ENH__
#include <apple2enh.h>
#pragma charmap (10, 13)

#include "a2simpleio.h"
#include "auxmemapple.h"
#include "pd_disk.h"
#endif

//Include memory-managing headers and define macros to
//minimize source code.
#ifdef __USEFARMEM__
#ifdef __C64__
#include "c64hide.h"
#elif defined __C128__
#include "membank128.h"
#define hidereadb bank1_readbyte
#define hidereadw bank1_readword
#elif defined __APPLE2ENH__
#define hidereadb aux_readbyte
#define hidereadw aux_readword
#define printh aux_print
#elif defined __ATARIXL__
#include "memxatari.h"
#define hidereadb aux_readbyte
#define hidereadw aux_readword
#elif defined __PLUS4__
#include "membankp4.h"
#define hidereadb bank1_readbyte
#define hidereadw bank1_readword
#define printh bank1_print
#endif
#else
#define hidereadb
#define hidereadw
#endif


//Put bss data in different systems' Low RAM via the
//Cubbyhole optimization technique.
#ifdef __C128__
#ifdef __USEFARMEM__
#pragma bss-name (push, "B1BSS")
#else 
#pragma bss-name (push, "APPBSS")
#endif
#elif defined __C64__
#pragma bss-name (push, "V2BSS")
#elif defined __PLUS4__
#pragma bss-name (push, "TAPEBSS")
#elif defined __ATARIXL__
#pragma bss-name (push, "TBUFBSS")
#elif defined __APPLE2ENH__
#pragma bss-name (push, "LOWBSS")
#endif

//Routine to print compressed string.
void __fastcall__ printtok (char*);

#pragma local-strings (off)

//Pointer to current alias being scanned.  Used to optimize
//alias scanning.
extern struct item_Alias* ita;
#pragma zpsym ("ita")

//Current item #.
extern unsigned char Itm1;
#pragma zpsym ("Itm1")

//Current room #.
extern unsigned char CRoom;
#pragma zpsym ("CRoom")

//Temp. variables.
extern unsigned char i, j, e, c;
#pragma zpsym ("i")
#pragma zpsym ("j")
#pragma zpsym ("e")
#pragma zpsym ("c")

extern char* s;
#pragma zpsym ("s")

//Current pos. in user input.
extern unsigned char CurPos;
#pragma zpsym ("CurPos")

#ifdef __ATARIXL__
#define printh aux_print
#elif defined __C128__
#define printh bank1_print
#endif

extern unsigned char c;
#pragma zpsym ("c")

//Contains the player's current command.
extern char Input [38];

//Put following code in memory stubs.
#ifdef __C128__
#pragma code-name (push, "APPCODE")
#elif defined __C64__ && defined __USEFARMEM__
#pragma code-name (push, "BAS2CODE")
#elif defined __C64__ && !defined __USEFARMEM__
#pragma code-name (push, "BAS2CODE")
#elif defined __PLUS4__
#pragma code-name (push, "CODE")
#elif defined __ATARIXL__
#pragma code-name (push, "MBUFCODE")
#endif
#if !defined __C128__ && !defined __APPLE2ENH__
#pragma code-name (pop)
#endif

//Current item during item scan.
extern unsigned char CurItem;
#pragma zpsym ("CurItem")

#ifdef __C128__
#pragma rodata-name (push, "TAPECONST")
#endif

//Common messages printed by this program.
//See enums in words.h.
const char* Message []=
{

/*  Message 0  */
	"You don't have that item.",
/*  Message 1  */
	"Your inventory is full.",

/*  Message 2  */
	"This room\'s inventory is full.",

/*  Message 3  */
	"You already have that.",

/*  Message 4  */
	"You can't go that way.",

/*  Message 5  */
	"That item is not available.",

/*  Message 6  */
	"Please be more specific."
};

#ifdef __C128__
#pragma rodata-name (pop)
#endif

#ifdef __C128__
#pragma code-name (push, "APPCODE")
#endif

#if defined __C64__ && defined __USEFARMEM__
#pragma code-name (push, "TAPECODE")
#endif

#ifdef __PLUS4__
#ifdef __USEFARMEM__
#pragma code-name (push, "CODE")
#else
#pragma code-name (push, "TAPECODE")
#endif
#endif

#ifdef __ATARIXL__
#pragma code-name (push, "TBUFCODE")
#endif

//Print message text for given #.
void __fastcall__ printmsg(unsigned char m);

#if defined __C64__ && !defined __USEFARMEM__
#pragma code-name (push, "TAPECODE")
#endif

//Middleman to add 15 to player score.  You can define others.
void addsc15 (void)
{Player.Score+=15;}

//Print item not found message.
void printnoitem (void)
{printmsg(msgItemNotAvail); }

//Print okay.
void printokay (void)
{printscr ("Okay.");}

//Pointer to current room entry.
extern struct room* CRm;
#pragma zpsym ("CRm")

//Pointer to current room's inventory.
extern unsigned char* CurRoomInv;
#pragma zpsym ("CurRoomInv");

#ifdef __PLUS4__
#ifdef __USEFARMEM__
#pragma code-name (push, "CODE")
#else
#pragma code-name (push, "BASICODE")
#endif
#endif

#ifdef __C128__
#pragma code-name ("APPCODE")
#endif

#if defined __C64__
#pragma code-name ("BAS2CODE")
#endif

#ifdef __ATARIXL__
#pragma code-name ("MBUFCODE")
#endif

#ifdef __APPLE2ENH__
#pragma code-name ("LOWCO")
#endif

//Prints a period followed by a return.
void __fastcall__ printperiod (void)
{printscr (".");}

//Prints the name of the current item indicated by Itm1.
static void __fastcall__ printitmname (void)
{
	//If a memory extension is used on a system other than a
	//C128, item names are stored in extended memory.
	//The C128 has enough unused Low memory to hold these.
#if defined __USEFARMEM__ && !defined __C128__
#if defined __C64__
	printtok (hidereadw((void*)&Item[/*CurRoomInv[i]*/Itm1].Name));
#elif defined __PLUS4__
	printtok (bank1_readword((void*)&Item[Itm1].Name));
#elif defined __ATARIXL__ || defined __APPLE2ENH__
	printtok (aux_readword((void*)&Item[Itm1].Name));
#endif
#else
	prints (Item[Itm1].Name);
#endif
}

#ifdef __PLUS4__
#pragma code-name (pop)
#endif

#ifdef __ATARIXL__
#pragma code-name ("MBUFCODE")
#endif

#if defined __C64__
#pragma code-name (pop)
#endif

#ifdef __PLUS4__ 
#pragma code-name (pop)
#endif

//Temp. pointer while processing user input.
//Holds address of noun in input.
extern char* inx;
#pragma zpsym ("inx")

#ifdef __C128__
#pragma code-name (push, "APPCODE")
#elif defined __PLUS4__ && defined __USEFARMEM__
#pragma code-name (push, "TAPECODE")
#elif defined __PLUS4__ && !defined __USEFARMEM__
#pragma code-name (push, "BASICODE")
#elif defined __ATARIXL__
#pragma code-name (push, "CODE")
#endif

#ifdef __APPLE2ENH__
#pragma code-name (push, "LOWCO")
#endif

//Versions of input routines for memory extended systems.
//Note that, on a C128, even when using Bank 1, the nouns and verbs
//are actually stored in a stub in Low memory, so using MemBank128's
//functions here is not necessary.
//I do this because it fits there.
#if defined __USEFARMEM__ && !defined __C128__
//Compares player noun to given word.
//Returns 1 if match an 0 otherwise.
static unsigned char __fastcall__ ScanWord (char* Dest)
{
	__asm__ (
		//Get test noun's location to zp variable.
		"\tjsr\tpopax\n"
		"\tsta\tptr4\n"
		"\tstx\tptr4+1\n"
		//tmp3 contains the offset in both the current input noun
		//and the test noun.
		"\tldy\t#0\n"
		"\tsty\ttmp1\n"
		"@a01:\n"
		//Load current character in input noun and
		//preserve for later check.
		"\tldy\ttmp1\n"
		"\tlda\t(%v),y\n"
		"\tsta\t_c\n"
		//Load test noun's current pointer
		//and call routine to read a character from
		//extended memory.
		"\tlda\tptr4\n"
		"\tldx\tptr4+1\n"
		"\tjsr\t%v\n"
		//Increment pointers.
		"\tinc\ttmp1\n"
		"\tinc\tptr4\n"
		"\tbne\t@a02\n"
		"\tinc\tptr4+1\n"
		"@a02:\n"
		//Compare text noun char. to user input noun.
		"\tcmp\t_c\n"
		//If !=, no match.
		"\tbne\t@a09\n"
		//If ==, check for end of input.
		"\tlda\t_c\n"
		//If so, match.
		"\tbne\t@a01\n"
		//Returns.
		"@a09:\n"
		"\tjmp\treturn1\n"
		"@a09a:\n"
		"\tjmp\treturn0\n"
		,
		inx, hidereadb
		);
}

#ifdef __PLUS4__
#pragma code-name (pop)
#endif
#ifdef __ATARIXL__
#pragma code-name ("MBUFCODE")
#endif

#ifdef __C128__
#pragma code-name (push, "TAPECODE")
#endif

#ifdef __APPLE2ENH__
#pragma code-name (push, "LOWCO")
#endif

//Searches for the verb given at the start of Input and returns the verb #.
//Returns 0xFF if not found.
unsigned char FindVerb (void)
{
	//j holds the current scan verb.
	j=0;
	//Loop to scan for matching verb.
	for (; j < NumVerbs; ++j)
	{
		//Start at pos. 0 in scans.
		for (CurPos=0;
			//C128's verbs are in a stub.
#ifdef __C128__
			//Load current character in both input verb and
			//test verb while comparing.
			(e=Input[CurPos]) == (c=(Verb[j].Name[CurPos])) &&
#else
			(c=(hidereadb(hidereadw((void*)&Verb[j].Name)+CurPos))) && 
			(e=Input[CurPos]) == c &&
#endif
			//If ==, check for end of verb and either space or NUL in input.
			e >= 33 && c
				; ++CurPos);
			//If so, return verb #.  Current pos. points to the character
			//after the input noun.
			if (Input[CurPos]<33 && c==0)
			{
				return j;
			}
	}
	//If no match found, skip to after verb and write 0
	//so that the main player function can print just the verb
	//in the error message.
	__asm__ (
		"\tldx\t_CurPos\n"
		"a00:\n"
		"\tlda\t_Input,x\n"
		"\tcmp\t#33\n"
		"\tbcc\ta01\n"
		"\tinx\n"
		"\tbne\ta00\n"
		"a01:\n"
		"\tstx\t_CurPos\n"
		"\tlda\t#0\n"
		"\tsta\t_Input,x\n"
		);
	//Return no verb.
	return -1;
}
#ifdef __C128__
#pragma code-name (pop)
#endif

#else
	
#ifdef __C128__
#pragma code-name (push, "TAPECODE")
#endif

//Compares the given word to the input noun.
//Returns 1 if equal and 0 if not.
static unsigned char __fastcall__ ScanWord (char* Dest)
{
	__asm__ (
		//Get test noun's location to zp variable.
		"\tjsr\tpopax\n"
		"\tsta\tptr4\n"
		"\tstx\tptr4+1\n"
		//Start at pos. 0.
		"\tldy\t#0\n"
		"@a01:\n"
		//Load current character in input noun and
		//preserve for later check.
		"\tlda\t(%v),y\n"
		"\tsta\t_c\n"
		//Compare test noun char. to input.
		"\tcmp\t(ptr4),y\n"
		//If !=, no match.
		"\tbne\t@a09a\n"
		//Otherwise, increment to next char.
		"\tiny\n"
		//Check for end-of-string.
		"\tlda\t_c\n"
		//If false, continue loop.
		"\tbne\t@a01\n"
		//Return conditions.
		"@a09:\n"
		"\tjmp\treturn1\n"
		"@a09a:\n"
		"\tjmp\treturn0\n",
		inx
		);
}

#ifdef __C128__
#pragma code-name (pop)
#endif

#if defined __PLUS4__
#pragma code-name (pop)
#endif

unsigned char FindVerb (void)
{
	//Loop to scan for matching verb.
	//j holds the current scan verb.
	for (j=0; j < NumVerbs; ++j)
	{
		//Start at pos. 0 in scan.
		CurPos=0;
		//Scan input and test verb and compare both.
		for (;
			//Compare and preserve current verb char.
			Input[CurPos]==(c=Verb[j].Name[CurPos]) &&
			//If ==, check for end of verb and either space or NUL in input.
			Input[CurPos] >= 33 && c
				;)
				{++CurPos;}
			//If so, return verb #.  Current pos. points to the character
			//after the input noun.
		if (!c && Input[CurPos]<33)
		{
			return j;
		}
	}
	//If no match found, skip to after verb and write 0
	//so that the main player function can print just the verb
	//in the error message.
	__asm__ (
		"\tldx\t_CurPos\n"
		"a00:\n"
		"\tlda\t_Input,x\n"
		"\tcmp\t#33\n"
		"\tbcc\ta01\n"
		"\tinx\n"
		"\tbne\ta00\n"
		"a01:\n"
		"\tstx\t_CurPos\n"
		"\tlda\t#0\n"
		"\tsta\t_Input,x\n"
		);
	//Input[i]=0;
	return -1;
}
#endif

#ifdef __APPLE2ENH__
#pragma code-name (pop)
#endif

#if !defined __C64__ && !defined __PLUS4__ && !defined __APPLE2ENH__
#pragma code-name (pop)
#endif

#if defined __USEFARMEM__
#ifdef __C128__
#pragma code-name (push, "APPCODE")
#endif

#if defined __ATARIXL__ && !defined __USEFARMEM__
#pragma code-name (pop)
#endif
//Gets the current location in user input and scans for a supported noun.
//Returns the item #.
#ifdef __ATARIXL__
#pragma code-name (pop)
#pragma code-name (push, "MBUFCODE")
#endif

#if defined __C64__ && !defined __USEFARMEM__

#pragma code-name (pop)
#endif

#ifdef __APPLE2ENH__
#pragma code-name (push, "LOWCO")
#endif

#if defined __PLUS4__ && !defined __USEFARMEM__
#pragma code-name (pop)
#endif

//Scan items for user input, memory extension.
unsigned char FindItem (void)
{
	//Cache and save address of noun in input.
	inx=&Input[CurPos];

/*  Search for item in Input */
	for (CurItem=0; CurItem < NumItems; ++CurItem)
	{
		//Use ScanWord() to find a match of the input noun
		//in the list of items.
#ifdef __C128__
		//On the C128, the list is in a stub.
		if (!strcmp(inx, Item[CurItem].Name)) {
#else
		if (ScanWord(hidereadw((void*)&Item[CurItem].Name))) {
#endif
			//If match, return match item #.
			return CurItem;
		}
	}
/*  Search item aliases */
	for (CurItem=0; CurItem < NumItemAliases; ++CurItem)
	{
		//If found, get and return the noun's alias.
		if (ScanWord(hidereadw((void*)(ita=&ItemAlias[CurItem])->Name))) {
			return hidereadb((void*)&ita->Num);
		}
	}

/*  Search item categories */
	for (CurItem=0; CurItem < NumItemCate; ++CurItem)
	{
		if (ScanWord(hidereadw((void*)&ItemCate[CurItem].Name))) {
			//Categories are between 128 and 159.
			return CurItem|128;
		}
	}

/*  Search directions  */
	for (CurItem = 0; CurItem < 4; ++CurItem)
	{
		//Directions are listed in thr RoomDir array in
		//wordsdb.c.
		if (ScanWord((char*)&RoomDir[CurItem])) {
			return CurItem | 160;
		}
	}
	//Return empty noun.
	return -1;
}

#else
//Versions without memory extension.
unsigned char FindItem (void)
{
	//Cache and save address of noun in input.
	inx=&Input[CurPos];
/*  Search for item in Input */
	for (CurItem=0; CurItem < NumItems; ++CurItem)
	{
		//Use ScanWord() to find a match of the input noun
		//in the list of items.
		if (ScanWord(Item[CurItem].Name)) {
			//If match, return match item #.
			return CurItem;
		}
	}
/*  Search item aliases */
	for (CurItem=0; CurItem < NumItemAliases; ++CurItem)
	{
		//If found, get and return the noun's alias.
		if (ScanWord((ita=&ItemAlias[CurItem])->Name)) {
			return ita->Num;
		}
	}

/*  Search item categories */
	for (CurItem=0; CurItem < NumItemCate; ++CurItem)
	{
		if (ScanWord(ItemCate[CurItem].Name)) {
			//Categories are between 128 and 159.
			return CurItem|128;
		}
	}
/*  Search directions  */
	for (CurItem = 0; CurItem < 4; ++CurItem)
	{
		//Directions are listed in thr RoomDir array in
		//wordsdb.c.
		if (ScanWord((char*)&RoomDir[CurItem])) {
			return CurItem | 160;
		}
	}
	//Return empty noun.
	return -1;
}
#endif
#if defined __ATARIXL__ && !defined __USEFARMEM__
#pragma code-name (pop)
#endif

#ifdef __C128__
#pragma code-name (pop)
#endif


#ifdef __C128__
#pragma code-name ("APPCODE")
#elif defined __C64__
#pragma code-name (push, "CODE")
#elif defined __PLUS4__ && !defined __USEFARMEM__
#pragma code-name (push, "BASICODE")
#endif

#if defined __C64__
#pragma code-name (push, "BAS2CODE")
#endif

#ifdef __ATARIXL__
#pragma code-name (push, "TBUFCODE")
#endif

//Adds the item # in Itm1 to the given inventory pointer.
//Returns 0 if successful and 1 if full.
unsigned char __fastcall__ AddInv (unsigned char* Inv)
{
	__asm__ (
		//Get pointer to inventory.
		"\tjsr\tpopax\n"
		"\tsta\tptr1\n"
		"\tstx\tptr1+1\n"
		//Start scan to find end of used inventory,
		"\tldy\t#0\n"
		"@a01:\n"
		//Load and test for -1 (empty entry).
		"\tlda\t(ptr1),y\n"
		"\tcmp\t#$FF\n"
		//If found, add Itm1 here.
		"\tbeq\t@a02\n"
		//If not, loop until end of inventory.
		"\tiny\n"
		"\tcpy\t#8\n"
		"\tbcc\t@a01\n"
		//If end, return full.
		"\tjmp\treturn1\n"
		"@a02:\n"
		//Load and write entry.
		"\tlda\t_Itm1\n"
		"\tsta\t(ptr1),y\n"
		//Go to next entry.
		"\tiny\n"
		"\tcpy\t#8\n"
		"\tbcs\t@a03\n"
		//If not full, write next blank.
		"\tlda\t#$FF\n"
		"\tsta\t(ptr1),y\n"
		"@a03:\n"
		"\tjmp\treturn0\n"
		);
};

#if defined __PLUS4__ && defined __USEFARMEM__
#pragma code-name (push, "TAPECODE")
#elif defined __PLUS4__ && defined __USEFARMEM__
#pragma code-name (push, "BASICODE")
#endif

//Middleman to add to player inventory.
unsigned char AddInvPlayer (void)
{return AddInv (Player.Inv);}

#if defined __PLUS4__
#ifdef __USEFARMEM__
#pragma code-name (pop)
#else
#pragma code-name ("BASICODE")
#endif
#endif

#if defined __C64__
#pragma code-name (pop)
#endif

#if defined __C64__
#pragma code-name ("ZP2CODE")
#endif

//Removes the item given in Itm1 from the inventory given by Inv.
//Returns 1 if successful and 0 otherwise.
unsigned char __fastcall__ RemoveInv (unsigned char* Inv)
{
	__asm__ (
		//Get pointer to inventory.
		"\tjsr\tpopax\n"
		"\tsta\tptr1\n"
		"\tstx\tptr1+1\n"
		//Start scan.
		"\tldy\t#0\n"
		"@a01:\n"
		//Load current item in inventory.
		"\tlda\t(ptr1),y\n"
		//If no item, exit 0 for error.
		"\tcmp\t#255\n"
		"\tbeq\t@a09\n"
		//If it matches the search item #, jump to remove code.
		"\tcmp\t_Itm1\n"
		"\tbeq\t@a02\n"
		//Advance and loop until current pos. is 8 for max.
		//size of inventory.
		"\tiny\n"
		"\tcpy\t#8\n"
		"\tbcc\t@a01\n"
		"@a09:\n"
		//Exit 0 if not found.
		"\tjmp\treturn0\n"
		"@a02:\n"
		//Close the gap left over to clear the current entry in
		//inventory by moving later entries down one.
		"\tiny\n"
		"\tlda\t(ptr1),y\n"
		"\tdey\n"
		"\tsta\t(ptr1),y\n"
		"\tiny\n"
		"\tcpy\t#8\n"
		"\tbcc\t@a02\n"
		//Naively set last pos. in inventory to -1
		//in case the inventory is full.
		//Otherwise, the end of inventory will also
		//be moved down.
		"\tlda\t#$FF\n"
		"\tldy\t#7\n"
		"\tsta\t\t(ptr1),y\n"
		//Return good.
		"\tjmp\treturn1\n"
		);
};

#if defined __C64__
#pragma code-name (pop)
#endif

#if defined __PLUS4__ && !defined __USEFARMEM__
#pragma code-name (pop)
#endif

/* Searches inventory at Inv for item Itm.
 * Returns 1 for found and 0 for not found.
 */
unsigned char __fastcall__ SearchInv (unsigned char* Inv, unsigned char Itm)
{
	__asm__ (
		//Get item to find.
		"\tjsr\tpopa\n"
		"\tsta\ttmp1\n"
		//Get address of inventory.
		"\tjsr\tpopax\n"
		"\tsta\tptr1\n"
		"\tstx\tptr1+1\n"
		//Start scan.
		"\tldy\t#0\n"
		"@a01:\n"
		//Load current byte in inventory.
		"\tlda\t(ptr1),y\n"
		//If no item, return not found.
		"\tcmp\t#$FF\n"
		"\tbeq\t@a09\n"
		//If match, return found.
		"\tcmp\ttmp1\n"
		"\tbne\t@a02\n"
		"\tjmp\treturn1\n"
		"@a02:\n"
		//Advance to next byte.
		"\tiny\n"
		//If end, not found.
		"\tcpy\t#8\n"
		"\tbcc\t@a01\n"
		"@a09:\n"
		"\tjmp\treturn0\n"
		);
}

#if defined __C64__
#pragma code-name (push, "BASINCODE")
#endif

#ifdef __C128__
#pragma code-name ("APPCODE")
#endif

#ifdef __PLUS4__
#ifdef __USEFARMEM__
#pragma code-name (push, "CODE")
#else
#pragma code-name (push, "BASICODE")
#endif
#endif

//SearchInv() middlemen.
//Search for item in Itm1.
unsigned char __fastcall__ SearchInv2 (unsigned char* Inv)
{
	return SearchInv (Inv, Itm1);
}

//Search player's inventory for item in Itm1.
unsigned char __fastcall__ SearchInvPlayer (void/*unsigned char* Inv*/)
{
	return SearchInv2 (Player.Inv);
}

//Search current room's inventory for item in Itm1.
unsigned char SearchInvRoom (void)
{return SearchInv2 (CurRoomInv);}

#if defined __C64__
#pragma code-name (pop)
#endif

#ifdef __PLUS4__ && !defined __USEFARMEM__
#pragma code-name (pop)
#endif

#ifdef __PLUS4__ && defined __USEFARMEM__
#pragma code-name (push, "TAPECODE")
#endif

#ifdef __APPLE2ENH__
#pragma code-name (push, "LOWCO")
#endif


//Scans given inventory for an item in the category specified by Itm1.
//Category #'s range from 128 to 159.
//Returns o if found, 1 if not and 2 if more than one item found.
//Also prints error messages.
#if defined __USEFARMEM__ && !defined __C128__
unsigned char __fastcall__ GetCateItem (/*register*/ unsigned char* Inv)
{
	//Convert item given to offset in category list.
	i=Itm1-128;
	//Default item not found.
	c=0xFF;
	//Only execute this code if the item is really a category.
	//Saves on extra check by calling routines.
	if (i<32) {
		//Scan category entry for a match of given inventory.
		for (j=0;
			//Scan until no item.
			(e=hidereadb((void*)&ItemCate[i].Items[j]))!=0xFF;
			++j)
		{
			//Search given inventory for current category's current item.
			if (SearchInv (Inv, e/*=hidereadb((void*)&ItemCate[i].Items[j])*/))
			{
				//If a match was already found, display Be More Specific error
				//and return condition.
				if (c!=0xFF) {printmsg(msgBeMoreSpec); return 2;}
				//If first found, save item #.
				c=e;
			}
		} //If matching item is not found, print Item Not Found error and return condition.
		if (c==0xFF) {
			printnoitem (); return 1;
		} //Write found item #.
		Itm1=c;
	} //Return good.
	return 0;
}

#else

#ifdef __PLUS4__
#pragma code-name (push, "TAPECODE")
#endif

//Searches the given inventory for items in the category given in Itm1.
//(Itm1 is from 128 to 159.)
/* Returns 0 if item found, 1 if unavailable and 2 if more than one item. */
unsigned char __fastcall__ GetCateItem (/*register*/ unsigned char* Inv)
{
	//Default item not found.
	c=-1;
	//Convert item given to offset in category list.
	i=Itm1-128;
	//Only execute this code if the item is really a category.
	//Saves on extra check by calling routines.
	if (i<32) {
		//Scan category entry for a match of given inventory.
		for (j=0;
			//Scan until no item.
			e=ItemCate[i].Items[j];
			++j)
		{
			//Search given inventory for current category's current item.
			if (SearchInv (Inv, e/*=hidereadb((void*)&ItemCate[i].Items[j])*/))
			{
				//If a match was already found, display Be More Specific error
				//and return condition.
				if (c!=0xFF) {printmsg(msgBeMoreSpec); return 2;}
				//If first found, save item #.
				i=e;
			}
		} //If matching item is not found, print Item Not Found error and return condition.
		if (c==0xFF) {
			printnoitem (); return 1;
		} //Write found item #.
		Itm1=c;
		//return 0;
	} //Return good.
	return 0;
}
#ifdef __PLUS4__
#pragma code-name (pop)
#endif

#endif
#pragma bss-name (pop)

#ifdef __PLUS4__ && defined __USEFARMEM__
#pragma code-name (pop)
#endif

#ifdef __ATARIXL__
#pragma code-name (pop)
#endif

#ifdef __C128__
#pragma code-name ("APPCODE")
#endif

#ifdef __PLUS4__
#pragma code-name (push, "CODE")
#endif

#ifdef __ATARIXL__
#pragma code-name (push, "MBUFCODE")
#endif

//Verb to describe the current item or scene.
void vLook (void)
{
	//Holds address of room handler code if describing room.
	//See rooms.c amd rooms.h.
	static void (*func)(void);
	//If an item is specified:
	if (Itm1!=0xFF) {
		//Far memory version.  C128 version's item entries are stored in a stub.
#if defined __USEFARMEM__  && !defined __C128__
		//If it is available in the player inventory,
		if (SearchInvPlayer () || SearchInvRoom ())
		{
			//get string address and print help text.
			if ((s=hidereadw((void*)&ItemPtr->Info))==0) {
				printscr ("No help available for that item.");
				return;
			}
			printtok (s); printcr ();
#else
		//If it is available in the player inventory,
		if (SearchInvPlayer () || SearchInvRoom ())
		{
			//get string address and print help text.
			if ((s=ItemPtr->Info)==0) {
				printscr ("No help available for that item.");
				return;
			}
			printscr (s);
#endif
		} else {
			printnoitem ();
		}
		return;
	}
	//Otherwise,
	//get room information
	CurRoomInv=&Player.RoomInv[CRoom];
	CRm=&Room[CRoom];
	//print it,
#ifdef __USEFARMEM__
	printtok ((char*)hidereadw((void*)&CRm->Desc));
	//call the room handler
	func=hidereadw((void*)&CRm->RoomHandler);
#else
	printtok (CRm->Desc);
	//call the room handler
	func=(CRm->RoomHandler);
#endif
	//Execute room handler.
	(*func) ();
	printcr();
	//and list room items.
	for (i=0; i<8 && (Itm1=CurRoomInv[i])!=0xFF;++i) {
		prints ("There is a ");
		//This function prints the name of the item specified by Itm1.
		printitmname ();
		printscr (" here.");
	}
}

#ifdef __PLUS4__
#pragma code-name (pop)
#endif

#ifdef __C64__
#pragma code-name (push, "TAPECODE")
#endif

#ifdef __C128__
#pragma code-name (push, "APPCODE")
#endif

//Middleman for vLook and no item specified.
void vLook2 (void)
{
	Itm1=-1;
	vLook ();

}

#ifdef __ATARIXL__
#pragma code-name (pop)
#endif

#ifdef __ATARIXL__
#pragma code-name (push, "MBUFCODE")
#endif

#ifdef __C64__
#pragma code-name (pop)
#endif

#ifdef __PLUS4__
#pragma code-name (push, "CODE")
#endif

#ifdef __C128__
#pragma code-name (push, "APPCODE")
#endif

//Change to different room.
#ifdef __USEFARMEM__
void vGo (void)
{
	//Convert Itm1 to dir #.
	Itm1-=160;
	//If a valid direction,
	if (Itm1<4) {
		//get destination room.
		if ((i=hidereadb(&(CRm->NextRoom[Itm1])))==0xFF) {
			//If not valid exit, error.
			goto err;
		} //Change room #.
		CRoom = i;
		//Describe new room and finish change-of-room.
		vLook2(); return;
	} //Error.
err:	printmsg(msgCantGoThere); return;
}
#else
void vGo (void)
{
	//Convert Itm1 to dir #.
	//If a valid direction,
	if ((Itm1-=160)<4) {
		//get destination room.
		if ((i=CRm->NextRoom[Itm1])==0xFF) {
			//If not valid exit, error.
			goto err;
		} //Change room #.
		CRoom = i;
		//Describe new room and finish change-of-room.
		vLook2(); return;
	} //Error.
err:	printmsg(msgCantGoThere); return;
}
#endif

#ifdef __APPLE2ENH__
#pragma code-name (pop)
#endif

#ifdef __PLUS4__
#pragma code-name (pop)
#endif

#ifdef __C64__
#pragma code-name (push, "BAS2CODE")
#endif

#ifdef __ATARIXL__
#pragma code-name ("TBUFCODE")
#endif

#ifdef __APPLE2ENH__
#pragma code-name (push, "LOWCO")
#endif

#if defined __PLUS4__ && defined __USEFARMEM__
#pragma code-name (push, "BASBCODE")
#endif

#ifdef __C64__
#pragma code-name (pop)
#endif

#if defined __C64__ && defined __USEFARMEM__
#pragma code-name (push, "BASINCODE")
#endif

//Middlemen for quick going (i.e. N S E W).
void vGoNorth	(void)
{
	Itm1=iNorth; vGo();
}

#if defined __C64__ && !defined __USEFARMEM__
#pragma code-name (push, "ZP2CODE")
#endif

void vGoSouth	(void)
{
	Itm1=iSouth; vGo();
}

void vGoEast	(void)
{
	Itm1=iEast; vGo();
}

void vGoWest	(void)
{
	Itm1=iWest; vGo();
}

#if defined __C64__ && !defined __USEFARMEM__
#pragma code-name (pop)
#endif

#if defined __C64__ && defined __USEFARMEM__
#pragma code-name (pop)
#endif

#if defined __PLUS4__ && !defined __USEFARMEM__
#pragma code-name (push, "BASBCODE")
#endif

//Verb-handling for picking up an item.
void vGet (void)
{
	//Check for category as noun.
	if (GetCateItem (CurRoomInv)) return;
	//Check if player inventory is full.
	if (Player.Inv[7] != 0xFF) {
		//If so, error.
		printmsg (msgHoldingTooManyItems);
		return;
	} //Check if item is movable.
#ifdef __USEFARMEM__
	if (hidereadb((void*)&ItemPtr->Attrib) & itemAMovable) {
#else
	if (ItemPtr->Attrib & itemAMovable) {
#endif
		//If movable, remove it from current room.
		if (!RemoveInv (CurRoomInv)) {
			//If not there, error.
			printnoitem ();
			return;
		}
		//Add it to the player's inventory.
		//Error condition was already checked.
		AddInvPlayer ();
		//Return.
		printokay ();
		return;
	}
	//If not movable, error.
	printscr ("You can't move this item."); //return;
}

#ifdef __PLUS4__
#pragma code-name (pop)
#endif

//Verb to drop an item.
void vPut (void)
{
	//Check for category.
	if (GetCateItem (Player.Inv)) return;
	//If player doesn't have the specified item, error.
	if (!SearchInvPlayer ()) {
		printmsg (msgDontHave); return;
	} //Check if item is movable.
#ifdef __USEFARMEM__
	if (((signed char)Itm1)>=0 && (hidereadb((void*)&ItemPtr->Attrib) & itemAMovable)) {
#else
	if ((signed char)Itm1>=0 && ItemPtr->Attrib & itemAMovable) {
#endif
		//If so, attempt to remove item from player's inventory.
		if (!RemoveInv (Player.Inv)) {
			//If not there, error.
			printnoitem ();
			return;
		} //Add it to room.
		if (AddInv (CurRoomInv))
		{
			//If error, put item back and display error..
			AddInvPlayer ();
			printmsg (msgTooManyItemsInRoom);
			return;
		}
		printokay ();
		return;
	} //If item is unmovable, display error message/
	printscr ("You can't move this item.");
}

#if defined __PLUS4__ && !defined __USEFARMEM__
//#pragma code-name (push, "GRCODE")
#endif

//Lists player's inventory.
void vItems (void)//char Itm1)
{
	printscr ("You have:");
	for (i=0; i<8 && (Itm1=Player.Inv[i])!=0xFF;) {
		printitmname (); printcr ();
		++i;
	}
	if (!i) printscr ("Nothing.");
}

#ifdef __ATARIXL__
#pragma code-name (pop)
#endif

#ifdef __C128__
#pragma code-name (pop)
#pragma code-name (pop)
#endif

#ifdef __APPLE2ENH__
#pragma code-name (pop)
#endif

//Displays help for current cndition.
void vHelp (void) {
	//This switch executes help for each room where help can be available.
	//For each room, you may perform other checks, such if the player has a
	//specific item or if a room is in a certain state. See the player.h file.
	switch (CRoom) {
	}
nohelp:
	printscr ("No help currently available.");
}

//Declares the help pages shown if player types "intro."
//If you need more pages, increase the subscript here and in
//the array's definition in wordsdb2.c and add pages there.
extern const char* HelpPages[2];

#ifdef __C128__
#pragma code-name (push, "APPCODE")
#endif

//Describes the game.
void vIntro (void)
{
	//For systems with expanded memory:
#ifdef __USEFARMEM__
	//Explicit call to clrscr() is needed on CBM targets because
	//the printtok() function uses the character as a token specifier.
	//If you need more pages, cop the following three lines and
	//increase the element by 1 each time.
	clrscr();
	printtok (hidereadw((void*)&HelpPages[0]));
	if ((getkey())=='x') return;
	clrscr();
	printtok (hidereadw((void*)&HelpPages[1]));
#else
	clrscr();
	printtok (HelpPages[0]);
	if (getkey()=='x') return;
	clrscr();
	printtok (HelpPages[1]);
#endif
}

#ifdef __C128__
#pragma code-name ("TAPECODE")
#endif

//Verb to read something.
void vRead (void)
{
	//Check if the item is in either the current room's
	//inventory or the player's inventory.
	if (SearchInvPlayer()) {
		if (SearchInvRoom()<0) {
			//Error if not.
			printnoitem ();
			return;
		}
	}
	//Switch for each item.
	//Add a case for each item that is readable, display text and
	//execute a return for eachy readable item.
	switch (Itm1)
	{
	} //Error for unreadable item.
	printscr ("Can't read this.");
}

#ifdef __C128__
#pragma code-name (pop)
#endif

