#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <errno.h>

//If using a memory extension, #include appropriate header file.
#ifdef __USEFARMEM__
#ifdef __C64__
#include "c64hide.h"
#elif defined __C128__
#include "membank128.h"
#elif defined __ATARIXL__
#include "memxatari.h"
#endif
#endif

//Get system's individual SimpleIO and disk-handling
//header files.
#ifdef __CBM__
#include "simpleio.h"
#elif defined __ATARIXL__
#include "atasimpleio.h"
#elif defined __APPLE2ENH__
#include <apple2enh.h>
//See top of Player.c file.
#pragma charmap (10, 13)

#include "a2simpleio.h"
#include "auxmemapple.h"
#include "pd_disk.h"
#endif

#include "aconst.h"
#include "rooms.h"
#include "words.h"
#include "player.h"
#include "stores.h"

//If using a memory extension, put room data in ext. memory.
#ifdef __USEFARMEM__
#ifdef __C64__
#pragma rodata-name (push, "HIDECONST")
#pragma data-name (push, "HIDEDATA")
#elif defined __C128__
#pragma rodata-name (push, "B1RODATA")
#pragma data-name (push, "B1DATA")
#elif defined __ATARIXL__
#pragma rodata-name (push, "AUXRO")
#pragma data-name (push, "AUXDATA")
#elif defined __PLUS4__
#pragma data-name (push, "B1DATA")
#pragma rodata-name (push, "B1RODATA")
#elif defined __APPLE2ENH__
#pragma data-name (push, "AUXRW")
#pragma rodata-name (push, "AUXRO")
#endif
#endif

//On some systems, put the null room handler in a stub.
#ifdef __C64__
#pragma code-name (push, "BAS2CODE")
#elif defined __C128__
#pragma code-name (push, "APPCONST")
#elif defined __ATARI__
#pragma code-name (push, "MBUFCODE")
#elif defined __PLUS4__
#pragma code-name (push, "CODE")
#else
#pragma code-name (push, "CODE")
#endif

//Empty function for rooms with no special handling code.
void rcNullRoom (void)
{ return;}
#pragma code-name (pop)

#ifdef __USEFARMEM__
#if defined __C128__ || defined __PLUS4__
#pragma rodata-name ("B1RODATA")
#pragma data-name ("B1DATA")
#elif defined __C64__
#pragma rodata-name ("HIDECONST")
#pragma data-name ("HIDEDATA")
#elif defined __ATARIXL__
#pragma rodata-name ("AUXRO")
#pragma data-name ("AUXDATA")
#endif
#endif

const struct room Room [] = {
{
/* Room 0 */
	"Room 1",	//Room name.
		"Description of Room 1.",	//Room description.
	//Address of room's handling routine.
	//This will be called when the room's information is being
	//displayed between the standard description and the items list.
	//rcNullRoom() is to be called if such is empty.
	&rcNullRoom,
	//Specify exits.
	//Either the number of the exit's room # or
	//-1 if not a valid exit.
	//Valid exits are assumed to be listed in the room's description.
	//If you want them displayed by the look verb instead,
	//contact me.
	{
		0, //North
		-1, //South
		-1, //East
		-1  //West
	}
}
};


const unsigned char DefRoomItems [NumRooms][8]=
{
	{iKey, -1}	//enums of items in each room, up to eight, followed by -1.
			//If eight items are in a room, don't follow with -1.
};

//Names of directions.
const char RoomDir [4][6] = {
	"north",
	"south",
	"east",
	"west"
};


