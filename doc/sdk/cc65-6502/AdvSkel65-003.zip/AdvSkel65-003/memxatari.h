#ifndef __cc65_ATARIXL_aux_H
#define __cc65_ATARIXL_aux_H

#include <stddef.h>

//----------------------------------------------------------------------
// Quick access:
//----------------------------------------------------------------------

/* Read value from Bank 1. */
unsigned char __fastcall__ aux_readbyte (void*);
unsigned int __fastcall__ aux_readword (void*);

/* Write value to Bank 1. */
void __fastcall__ aux_writebyte (void*, unsigned char);
void __fastcall__ aux_writeword (void*, unsigned int);

//----------------------------------------------------------------------
// Basic memory functions:
//----------------------------------------------------------------------
/* Copy a data block from Bank 0 to Bank 1 */
void __fastcall__ aux_memcpyto (void* dest, void* sour, unsigned len);
/* Copy a data block from Bank 1 to Bank 0 */
void __fastcall__ aux_memcpyfrom (void* dest, void* sour, unsigned len);
/* Copy a data block in Bank 1 */
void __fastcall__ aux_memcpyin (void* dest, void* sour, unsigned len);

int __fastcall__ aux_memcmpto (const void* p1, const void* p2, size_t count);
int __fastcall__ aux_memcmpfrom (const void* p1, const void* p2, size_t count);
int __fastcall__ aux_memcmpin (const void* p1, const void* p2, size_t count);
char* __fastcall__ aux_strchr (const char* s, int c);
char* __fastcall__ aux_strrchr (const char* s, int c);

void* __fastcall__ aux_memset (void* s, int c, size_t count);
void __fastcall__ aux_bzero (void* s, size_t count);
//----------------------------------------------------------------------
// Bank 1 string operations:
//----------------------------------------------------------------------
int __fastcall__ aux_strlen (char* s);
char* __fastcall__ aux_strcpyin (char* dest, char* sour);
char* __fastcall__ aux_strcpyto (char* dest, char* sour);
char* __fastcall__ aux_strcpyfrom (char* dest, char* sour);
void __fastcall__ aux_print (const char* s);

char* __fastcall__ aux_strstrin (char* dest, char* sour);
char* __fastcall__ aux_strstrto (char* dest, char* sour);

//Load a given file into aux. mem.
unsigned char loadauxmem (char* f);

#endif

