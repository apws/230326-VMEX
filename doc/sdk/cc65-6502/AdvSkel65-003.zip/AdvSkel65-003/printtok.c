/***********************************************************************
 * 
 * Individual module for the cc65 compiler.
 *
 * The template for this file was created by TempC Module Creator by
 * Joseph Rose.  This template can be used in your programs, provided
 * you mention TempC in your software's documentation.  If this source
 * code is distributed, this copyright must be included in the file.
 *
 ***********************************************************************/

#include <ctype.h>

//Replace with the name of your copy of CBMSimpleIO's header file.
#include "simpleio.h"

//This is needed, as the routine calls itself.
//#pragma static-locals (off)

// void printc(char);
// void prints (char*);
// void printcr(void);

//extern unsigned char* brdrcol;
//If you're using one of my memory extenders, #define 
//__USEFARMEM__ on the compiler command line.
#ifdef __USEFARMEM__
#ifdef __C64__
#define extreadbyte hidereadb
#define extreadw hidereadw
#elif defined __C128__ || defined __PLUS4__
#define extreadbyte bank1_readbyte
#define extreadw bank1_readword
#elif defined __ATARIXL__ || defined __APPLE2ENH__
#define extreadbyte aux_readbyte
#define extreadw aux_readword
#endif
unsigned char __fastcall__ extreadbyte (void*);
unsigned __fastcall__ extreadw (void*);
#else
unsigned char extreadbyte (char* c)
{return *c;}
#endif

// void printu (unsigned); 
// unsigned char getkey(void);

//This is needed, as the routine calls itself.
//#pragma static-locals (off)

//Insert your tokens here  This holds the first 32 tokens.
//Refer to these tokens  by writing the escape sequence \x80 and
//add the token # to the escape sequence.  If programming
//for gthe Atari 8-bit series, use \xA0 instead.
static char * tokens[]=
{
	"Mars"
}, 
//More tokens.  Refer to these with a % followed by a lowercase letter.

* tokens2a[]= {
	"Microsoft",
	"Harry Potter"
},
//Even more tokens.  Use if needed.  Refer with an uppercase letter.
* tokens2b[]=
{
	"Illegal function call."
}
;

void bank1_print (char*);

//RLE for spaces instructions:
//
//If you want to print at least three spaces, you can use
//the escape sequence \x05 followed by a digit 3 less then
//the number of spaces you need.  Maximum is 12 spaces
//at a time.

//This function prints the string given in str to the screen
//with one difference: if a string literal between 0x80 and 0x9F
//is found, it will print the token # that literal-0x80.
//
//BTW, you need to include this prototype in your
//program's modules.
void __fastcall__ printtok (char* str)
{
	unsigned char i;
//prints (str); printcr(); getkey();
#ifdef __USEFARMEM__
	//str=extreadw (str);
#endif
	while (i=(extreadbyte(str))) {
//printu (i); printc (' '); getkey();
		//i=*str;
#ifdef __ATARI__
		if (i>=0xA0 && i<0xC0) prints (tokens[i&0x1F]);
#else
		if (i>=0x80 && i<0xA0) prints (tokens[i&0x1F]);
#endif
		//Kill this condition if you need no more than 32
		//tokens:
		else if (i=='%') {
			++str; i=extreadbyte(str);
			//printtok (tokens[*str-'a']);
			if (i=='%') {
				printc ('%');
			}
			else if (islower(i)) {
				prints (tokens2a[i-'a']);
			}
			//Kill this condition if you need no
			//more than 58 tokens:
			else if (isupper(i)) {
				prints (tokens2b[i-'A']);
			}
		} else if (i==5) {
			++str; i=extreadbyte(str)-'0'+3;
			while (i--) printc (' ');
		}
		else printc (i);
		++str;
	}
}

