

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <errno.h>
#include <ctype.h>

#include "words.h"
#include "rooms.h"
#include "player.h"
#include "input.h"

//Include versions of SimpleIO and disk I/O libraries for each input.
#ifdef __CBM__
#include "simpleio.h"
#elif defined __ATARIXL__
#include "atasimpleio.h"
#include "atadisk65.h"
#elif defined __APPLE2ENH__
#include <apple2enh.h>
//This routes on Apple2enh systems the line feeds to Return characters.
//This is needed, as the '\n' on other systems is '\r' on the Apple2enh.
#pragma charmap (10, 13)

#include "a2simpleio.h"
#include "auxmemapple.h"
#include "pd_disk.h"

#endif

//If using a system's extra memory, #include the header file containing
//the functions that handle such memory
//and alias to the C64's function names
//so that there is less code.
#ifdef __USEFARMEM__
#ifdef __C64__
#include "c64hide.h"
#elif defined __C128__
#include "membank128.h"
#define hidereadb bank1_readbyte
#define hidereadw bank1_readword
#define printh bank1_print
#elif defined __APPLE2ENH__
#define hidereadb aux_readbyte
#define hidereadw aux_readword
#define printh aux_print
#elif defined __ATARIXL__
#include "memxatari.h"
#define hidereadb aux_readbyte
#define hidereadw aux_readword
#define printh aux_print
#elif defined __PLUS4__
#include "membank128.h"
#define hidereadb bank1_readbyte
#define hidereadw bank1_readword
#define printh bank1_print
#endif
#else
#define hidereadb
#define hidereadw
#endif

//Used by the Hidden memory version of the C64 port to load the
//contents of Hidden memory.
int hideloadfile2 (void);

struct player_ Player;

//These use a system's low RAM to store some BSS data.
#ifdef __C128__
#ifdef __USEFARMEM__
#pragma bss-name (push, "B1BSS")
#else 
#pragma bss-name (push, "APPBSS")
#endif
#elif defined __C64__
#pragma bss-name (push, "V2BSS")
#elif defined __PLUS4__
#pragma bss-name (push, "BSS")
#elif defined __ATARIXL__
#pragma bss-name (push, "BSS")
#elif defined __APPLE2ENH__
#pragma bss-name (push, "LOWBSS")
#endif

//Current room #.
extern unsigned char CRoom;
#pragma zpsym ("CRoom")

//Temp. variables.
extern unsigned char i, j;
#pragma zpsym ("i")
#pragma zpsym ("j")

//Current varb #.
extern unsigned char Vrb;
#pragma zpsym ("Vrb")

//Current pos. in user input string.
extern unsigned char CurPos;
#pragma zpsym ("CurPos")

//Temp. variables.
extern unsigned char c;
#pragma zpsym ("c")

extern unsigned char *s;
#pragma zpsym ("s")

//Pointer to current room data.
extern struct room* CRm;
#pragma zpsym ("CRm")

//Middleman to look w/out item.
void vLook2 (void);

//Middleman to print a period folowed by a CR.
void __fastcall__ printperiod (void);

//Array to hold user input.
#ifdef __C128__
char Input [78];
#elif defined __C64__
#pragma bss-name (pop)
char Input [38];
//#pragma bss-name (push, "V2BSS")

#pragma bss-name (push, "V2BSS")
#else
char Input [38];

#endif

//Routine to load the stubs on CBM machines.
//fi[] holds the name of the first stub, and, before
//function exit, the number is incremented.
#ifdef __CBM__
#ifdef __C64__
static char fi[]="stub1";
void __fastcall__ load2 (void)
#elif defined __PLUS4__
#pragma code-name (push, "LOWCODE")
#pragma data-name (push, "LOWCODE")
static char fi[]="adv-low1";

void __fastcall__ load2 (void)
#elif defined __C128__
static char fi[]="lowmem1";

void __fastcall__ load2 (void)
#endif
{
	__asm__ (
//Switch in kernal ROM on the Plus4 and C128.
#ifdef __PLUS4__
		"\tsta\t$FF3E\n"
#elif defined __C128__
		"\tsta\t$FF03\n"
#endif
//Open file.
		"\tlda\t#0\n"
		"\tldx\t#8\n"
		"\tldy\t#1\n"
		"\tjsr\tSETLFS\n"
#ifdef __C64__
		"\tlda\t#5\n"
#elif defined __C128__
		"\tlda\t#7\n"
#elif defined __PLUS4__
		"\tlda\t#8\n"
#endif
		"\tldx\t#<_fi\n"
		"\tldy\t#>_fi\n"
		"\tjsr\tSETNAM\n"
//Load the stub into memory.
		"\tlda\t#0\n"
		"\ttax\n"
		"\ttay\n"
		"\tjsr\tLOAD\n"
//Switch back RAM on the Plus4 and C128.
#ifdef __PLUS4__
		"\tsta\t$FF3F\n"
#elif defined __C128__
		"\tsta\t$FF01\n"
#endif
		);
//Increment the number of the file to load for next stub.
#ifdef __C64__
	++fi[4];
#elif defined __PLUS4__
	//fi[7]=t;
	++fi[7];
//printc ('.'); getkey();
#elif defined __C128__
	++fi[6];
#endif
}

#ifdef __C128__
#pragma code-name (push, "APPCODE")
#endif
#ifdef __PLUS4__
#pragma data-name (pop)
#pragma code-name ("TAPECODE")
#endif

#if defined __ATARIXL__
#pragma code-name (push, "MBUFCODE")
#endif

#if defined __PLUS4__ && defined __USEFARMEM__
#pragma code-name (push, "BASICODE")
#endif
#if defined __PLUS4__ && !defined __USEFARMEM__
#pragma code-name (push, "CODE")
#endif


#if defined __C64__ && !defined __USEFARMEM__
#pragma code-name (push, "TAPECODE")
#endif

//Routines to load and save gamw on CBM computers.
//Pass the filename in c.
void loadgame (char* c)
{
	cbm_open (1, 8, CBM_READ, c);
	cbm_read (1, &Player, sizeof (Player));
	cbm_close (1);
}

#if defined __C64__ && !defined __USEFARMEM__
#pragma code-name (pop)
#endif

#if defined __PLUS4__ && defined __USEFARMEM__
#pragma code-name ("ZP2CODE")
#endif

#if defined __PLUS4__ && !defined __USEFARMEM__
#pragma code-name ("BASICODE")
#endif

void savegame (char* c)
{
	cbm_open (1, 8, CBM_WRITE, c);
	cbm_write (1, &Player, sizeof (Player));
	cbm_close (1);
}

#if defined __PLUS4__ && defined __USEFARMEM__
#pragma code-name (pop)
#endif

#if defined __ATARIXL__
#pragma code-name ("MBUFCODE")
#endif

#ifdef __PLUS4__
#pragma code-name ("BASICODE")
#endif
#ifndef __C64__
#pragma code-name (pop)
#endif
#endif

#ifdef __ATARIXL__
#pragma code-name (push, "TBUFCODE")
#endif

#ifdef __PLUS4__
#ifdef __USEFARMEM__
#pragma code-name (push, "CODE")
#else
#pragma code-name (push, "CODE")
#endif
#endif
#ifdef __C128__
#pragma code-name (push, "APPCODE")
#endif

#if defined __C64__ && !defined __USEFARMEM__
#pragma code-name (push, "ZP2CODE")
#endif

#if defined __C64__ && defined __USEFARMEM__
#pragma code-name (push, "BASINCODE")
#endif

//Routine to skip space between verb and noun in user input.
void eatwhitei (void)
{
	// __asm__ (
		// "\tldx\t_CurPos\n"
		// "\tlda\t_Input,x\n"
		// "\tcmp\t#32\n"
		// "\tbne\t@a01\n"
		// "\tinc\t_CurPos\n"
		// "@a01:\n"
		// );
	if (Input[CurPos]==32) ++CurPos;
}


#if defined __PLUS4__ && !defined __USEFARMEM__
#pragma code-name (pop)
#endif


#if defined __C64__
#pragma code-name (pop)
#endif


#if defined __C64__ && !defined __USEFARMEM__
#pragma code-name (push, "BASINCODE")
#endif

#ifdef __APPLE2ENH__
#pragma code-name (push, "LOWCO")
#endif


//Second part of player init routine.  To be stored in a stub.
void InitPlayer2 (void)
{
	//Clear player inventory.  Value 255 means no item.
	__asm__ (
		"\tlda\t#255\n"
		"\tldx\t#7\n"
		"@a01:\n"
		"\tsta\t%v+%w,x\n"
		"\tdex\n"
		"\tbpl\t@a01\n",
		Player, offsetof (struct player_, Inv)
		);
//On the C128 and the Apple2enh, get player name here.  On other
//systems, the InitPlayer() routine requests player name.
//If you don't want the player name, you can kill this code and
//remove the entry in the player struct in the "player.h" file.
#if defined __C128__ || defined __APPLE2ENH__
	printscr("What is your name?  (No more\n"
		 "than 15 characters)?");
	GetInput (Player.Name, 15);
#endif
//Copy default room items to player struct's room inventories.
//Some extra work is required for memory extensions, as they come
//from the extra memory.
#ifdef __USEFARMEM__
#if defined __APPLE2ENH__ || defined __ATARIXL__
	aux_memcpyfrom (&Player.RoomInv, &DefRoomItems, (NumItems<<3));
#elif defined __PLUS4__ || defined __C128__
	bank1_memcpyfrom (&Player.RoomInv, &DefRoomItems, (NumItems<<3));
	//bank1_memcpyfrom (0xC00, &DefRoomItems, (NumItems<<3));
#elif defined __C64__
	hmemcpy (&Player.RoomInv, &DefRoomItems, (NumItems<<3));
#else
	memcpy (&Player.RoomInv, &DefRoomItems, (NumItems<<3));
#endif
#else
	memcpy (&Player.RoomInv, &DefRoomItems, (NumItems<<3));
#endif
//Set current room to #0/first room.
	CRoom=0;
}
#if defined __C64__ && !defined __USEFARMEM__
#pragma code-name (pop)
#endif

#ifdef __PLUS4__
#pragma code-name (pop)
#endif

#ifdef __ATARIXL__
#pragma code-name (pop)
#endif
#ifdef __C128__
#pragma code-name (pop)
#endif

#ifdef __APPLE2ENH__
#pragma code-name (pop)
#endif


//Loads stubs and sets up the player data.
void InitPlayer (void)
{
#ifdef __C64__
	prints ("Loading data...");
	load2 ();
	load2 ();
	load2 ();
	load2 ();
#ifdef __USEFARMEM__
	hideloadfile2();
#endif
#elif defined __C128__
	prints ("Loading data...");
	//Set default load and filename banks to Bank 0/normal RAM.
	__asm__ (
		"\tldx\t#0\n"
		"\tstx\ttmp4\n"
		"\tlda\t#$68\n"
		"\tjsr\tcallkernal\n"
		);
//Load the first two stubs.  The other stubs are empty.
//If you need more stubs, add an extra loads here.
	load2 ();
	load2 ();
//If using 128k on a C128, load in the far/Bank1  data.
#ifdef __USEFARMEM__
	bank1_cbm_load ("bank1stub", 8, 0);
#endif
#elif defined __PLUS4__
	printscr ("Loading data...");
	load2 ();
	load2 ();
#ifndef __USEFARMEM__
	load2 ();
#else
	++fi[7];
	load2 ();
#endif
#ifdef __USEFARMEM__
	//On a 256k Plus4, this loads data into the Hannes memory.
	bank1_cbm_load ("bank1,s", 8, 0x1000);
#endif
#elif defined __ATARIXL__
	prints ("Loading data...");
	cio_load (1, "D1:TAP.BIN", 0x3FD, 0x303);
	cio_load (1, "D1:MEMX1.BIN", 0x15A4, 0x442);
#ifdef __USEFARMEM__
	loadauxmem ("D1:AUX1.BIN");
#endif
#elif defined __APPLE2ENH__
#ifdef __USEFARMEM__
	aux_init ();
#endif
	prints ("Loading data...");
	loadstub ("/PRODOS203/LOWMEM", 0x0800);
#ifdef __USEFARMEM__
	loadauxro ("/PRODOS203/AUXRO");
#endif
#endif
//On the C128 and Apple2enh, the player name is asked in the InitPlayer2() stub.
//Otherwise, it is asked here, as Those versions have enough Low memory for it.
#if !defined __C128__ && !defined __APPLE2ENH__
	printscr("Done!\nWhat is your name?  (No more\n"
		 "than 15 characters)?");
	GetInput (Player.Name, 15);
#endif
	InitPlayer2 ();
}

#ifdef __C128__
#pragma code-name (push, "APPCODE")
#elif defined __C64__
#pragma code-name (push, "TAPECODE")
#elif defined __PLUS4__
#pragma code-name (push, "TAPECODE")
#elif defined __ATARIXL__
#pragma code-name (push, "TBUFCODE")
#elif defined __APPLE2ENH__
#pragma code-name (push, "LOWCO")
#endif

//Routine to get user input.
//In holds the information typed by the user
//and InLen in the max. len. of the input without
//the terminating NUL.
#ifdef __CBM__
//CBM version.

unsigned char __fastcall__ GetInput (char* In, unsigned char InLen)
{
	//Set to start of line.
	CurPos=0;
	//Write prompt.
	printc ('>');
	//Main input loop.
	while (1)
	{
		//Emulate cursor.
		printc ('_');
		//Get key.
		i = getkey ();
		//Delete emulated cursor.
		printc (20);
		//Process input.
		//If Return,
		if (i==13){
			//Write terminator and
			//return length of input, without
			//the NUL, and print Retur..
			In[CurPos]=0;
			printcr ();
			return CurPos;
		//If delete and not at the beginning of input,
		} if (i == 20 && CurPos) {
			//cursor left in input
			--CurPos;
			//and delete last character.
			printc (20);
		//If printable char. and input not full,
		} if ((i&0x60) && CurPos<InLen) {
			//print it and add it to the input.
			In[CurPos]=i;
			printc (i);
			++CurPos;
		}
	}
}

#elif defined __APPLE2ENH__
//Apple2enh version:
unsigned char __fastcall__ GetInput (char* In, unsigned char InLen)
{
	//Set to start of line.
	CurPos=0;
	//Prompt.  If you desire a different prompt, print it
	//here.
	printc ('>');
	//Main loop:
	while (1)
	{
		//Get key press and clear the sign bit.
		i = getkey ()&127;
		//Process key press.
		if (i=='\n'){ 			//If Return,
			In[CurPos]=0;		//Terminate input string.
			printcr ();		//Go to next screen line.
			return CurPos;			//Return string len.
		} else if (i == 127 && CurPos) { 	//If delete,
			//Won't be processed if the buffer is empty.
			--CurPos;		//Cursor left.
			printc ('\b');		//Delete last char. from screen.
			printc (' ');
			printc ('\b');
		//If printable char. and input not full,
		} else if (isprint(i) && i!=127 && CurPos<InLen) { //Printable char.
			printc (In[CurPos]=i);	//Add key to buffer and advance.
			++CurPos;
		}
	}
}

//Atari8 version:
#else
unsigned char __fastcall__ GetInput (char* In, unsigned char InLen)
{
	//Set to start of line.
	CurPos=0;
	//Prompt.  If you desire a different prompt, print it
	//here.
	printc ('>');
	//Main loop:
	while (1)
	{
		//Display emulated cursor: I wasn't able to get the cursor
		//to work here.
		printc ('_');
		//Get key press.
		i = getkey ();
		//Delete cursor.
		printc (CH_DEL);
		//Process key press.
		if (i==CH_ENTER){		//If Return,
			In[CurPos]=0;		//Terminate input string.
			printcr ();		//Go to next screen line.
			return CurPos;		//Return string len.
		} if (i == CH_DEL && CurPos) {	//If delete,
			--CurPos;
			printc (CH_DEL);
		//If printable char. and input not full,
		} else if ((i&0x60) && CurPos<InLen) {
			In[CurPos]=i;		//Add key to buffer and advance.
			printc (i);
			++CurPos;
		}
	}
}

#endif
#pragma code-name (pop)

#ifdef __C128__
#pragma code-name (push, "APPCODE")
#elif defined __ATARIXL__
#pragma code-name (push, "MBUFCODE")
#endif

#ifdef __APPLE2ENH__
#pragma code-name (push, "LOWCO")
#endif

//Displays current room name and score at top of screen.
void DispScoreBoard ()
{
/* Display status */
//CBM version.
#ifdef __CBM__
//Get the current screen line; column is assumed to be 0.
//wherey() shouldn't be needed; I need to optimize later.
#if defined __PLUS4__
	c=wherey();
#else
	c=taby;
#endif
	//Home and set reverse mode.
	//home2();
	printc (0x13);
	reverson();
	//For the C128 (80 column version)
#ifdef __C128__
	//clear to row.
	for (i=79; i; --i) printc (32);
	//If using far memory, special memory access functions are needed.
#ifdef __USEFARMEM__
	//Display room name.
	prints ("\x13Room: "); printh (hidereadw((void*)&CRm->Name));
	//Display score at right edge of screen.
	tabx=69; prints ("Score "); printu (Player.Score); printcr ();
	//Using only Bank 0, access is more direct.
#else
	//Display room name.
	prints ("\x13Room: "); prints (Room[CRoom].Name);
	//Display score at right edge of screen.
	tabx=69; prints ("Score "); printu (Player.Score); printcr ();
#endif
//40-column CBM computers:
#else
	//reverson();
	//Clear status bar.
	for (i=39; i; --i) printc (32);
//If using far or hiddem memory
#ifdef __USEFARMEM__
	//Display room name.
	prints ("\x13Room: "); printh (hidereadw((void*)&CRm->Name));
	//Display score at right edge of screen.
	tabx=29; prints ("Score "); printu (Player.Score); printcr ();
//Otherwise:
#else
	//Display room name.
	prints ("\x13Room: "); prints (CRm->Name);
	//Display score at right edge of screen.
	tabx=29; prints ("Score "); printu (Player.Score); printcr ();
#endif
#endif
	//Return to row before the call to DispScoreBoard().
	goline (c);
//Atari8 version:
#elif defined __ATARIXL__
	//Preserve current cursor row; column is assumed to be 0.
	c=wherey();
	//Home the cursor.
	gotoxy (0, 0);
	//Clear the score board with reversed spaces.
	for (i=39; i; --i) printc (32|128);
	//Reset the X pos. to print score board.
	tabx=0;
	//Write the score board.  Note that, due to an unsupported feature of
	//AtaSimpleIO, some information will not be printed in reverse.
#ifdef __USEFARMEM__
	printrs ("Room: "); printh (hidereadw((void*)&CRm->Name));
	tabx=29; printrs ("Score "); printu (Player.Score); printcr ();
#else
	printrs ("Room: "); printrs (CRm->Name);
	tabx=29; printrs ("Score "); printu (Player.Score); printcr ();
#endif
	//Return to orig. row.
	gotoy (c);
	//Apple2enh version.
#elif defined __APPLE2ENH__
	//Get row #.
	c=wherey();
	//Home the cursor and turn reverse mode on.
	//home2();
	gotoxy (0, 0);
	reverson ();
	//Clear score board.
	for (i=79; i; --i) printc (32);
	//Return to left of score board.
	//For some reason, when I issue "tabx=0;" or "gotox(0);"
	//here, the cursor doesn't move all the way to the left.
	//Even "tabx=1; --tabx;" doesn't work.  I don't know why
	//this is, so I had to do a workaround.
	printcr(); gotoy (0);
	//Print score board.
#ifdef __USEFARMEM__
	prints ("Room: "); printh (hidereadw((void*)&CRm->Name));
	tabx=69; prints ("Score "); printu (Player.Score); //printcr ();
#else
	prints ("Room: "); prints (CRm->Name);
	tabx=69; prints ("Score "); printu (Player.Score); //printcr ();
#endif
	//Clear reverse mode and return to orig. row.
	reversoff(); printcr (); gotoy (c);
#else
	//For other computers.  I don't remember the purpose of this code.
#ifdef __USEFARMEM__
	prints ("\x13Room: "); printh (hidereadw((void*)&CRm->Name));
	tabx=29; prints ("Score "); printu (Player.Score); printcr ();
#else
	prints ("\x13Room: "); prints (CRm->Name);
	tabx=29; prints ("Score "); printu (Player.Score); printcr ();
#endif
	goline (c);
#endif
}
#pragma bss-name (pop)

#if defined (__ATARIXL__) || defined (__C128__)
#pragma code-name (pop)
#endif

#ifdef __APPLE2ENH__
#pragma code-name (pop)
#endif

//main() function.

void main (void)
{
	//Holds address of function of verb handler.
	static void (* vfunc) ();
#ifdef __C128__
	//On a C128, prompt user to switch monitor mode and
	//switch to 80-column mode.
	printscr ("Please switch to 80-column mode now.");
	videomode (VIDEOMODE_80COL);
	//Set background color to white.
	bgcolor (1);
	//Set colors for C64 version.  Other systems may need similar
	//code.
#elif defined __C64__
	brdrcol=8;
	backcol=1;
	//For the Apple2enh target,
#elif defined __APPLE2ENH__
	//set to 80-column mode and
	videomode (VIDEOMODE_80COL);
#ifdef __USEFARMEM__
	//if using aux memory, initialize memory environment.
	//This routine disables the RAM drive.
	//There is currently no way to reenable it,
	//so you have to reset the system if you plan to
	//exit the game.
	aux_init();
#endif
#endif
	//Display start-up banner.
	//Replace the text given with what your text adventure needs.
#ifdef __CBM__
	printscr("\f\n\x9cWelcome to \"Adventures on Planet Smir\n"
		 "III, Episode 1, v .10\" for the Commo-\n"
		 "dore 64 and emulators, created with cc65"
		 "by Joseph Rose.\n\n"

		 "Type INTRO during the game for\n"
		 "instructions.\n\n"
		 "Do you want to load a saved game?");
#else
	clrscr ();
	printscr("Welcome to \"Adventures on Planet Smir\n"
		 "III, Episode 1, v .10\" for the Commo-\n"
		 "dore 64 and emulators, created with cc65"
		 "by Joseph Rose.\n\n"

		 "Type INTRO during the game for\n"
		 "instructions.\n\n"
		 "Do you want to load a saved game?");
#endif
	//Get usr press.  This sets c to 0 for no, 1 for yes and
	//2 if you want to enter debug mode.
	//Debug mode allows you to switch to any room you want at
	//start-up.  If you don't want this, disable the case 'd' and
	//the condition below starting with "if (c==2)."
	c=0;
	switch (getkey ())
	{
	case 'd': ++c;		//Debug mode: start in specified room #.
	case 'y': ++c;		//Load saved game.
	}
	InitPlayer ();
// printc ('.');
	//Put game load code here at option c==1.
	
	//If debug mode, get start room # and switch to room.
	if (c==2) {
		//Print prompt and get input.
		printscr ("Debug mode: Enter room #"); GetInput (Input, 4);
		//CRoom is already set to 0.
		//Scan input and, for each digit, multiply CRoom by 10
		//and add digit.  Assumes all characters are digits.
		for (CurPos=0;Input[CurPos]; ++CurPos)
		{
			CRoom=(((CRoom<<2)+CRoom)<<1)+(Input[CurPos]&0xF);
		}
	}
	//Display default room.
	vLook2 ();
	//Main loop.
	while (1)
	{
		//Display the score board.
		DispScoreBoard();
		//Get user input and loop if empty.
		if (!GetInput (&Input,38)) continue;
		//Get verb #.
		Vrb = FindVerb ();
		//Verbs are assumed to be positive.  If negative, invalid verb.
		if ((signed char)Vrb<0) {
			//Print error and loop.
			prints ("I don't know how to ");
			prints (Input); 
			printperiod ();
			continue;
		}
		//Skip space if it's after verb.
		eatwhitei ();
		//Set default value to item as no item.
		Itm1=0xFF;
		//If character at current pos. in input is not 0,
		if (Input[CurPos])
		{
			//Get item #.
			if ((Itm1 = FindItem ())==255) {
				//If no item, error and loop.
				prints ("I don't know what a ");
				prints (&Input[CurPos]);
				printscr (" is.");
				continue;
			} 
			//Get item information ptr. to current item's entry.
			ItemPtr=&Item[Itm1];
		}
//printu (Itm1);
		//Get verb member handling routine's address.
runverb:
		//If using memory extension, the data is in ext. memory
		//except for the C128, where they are stored in
		//a stub.
#if defined __USEFARMEM__ && !defined __C128__
		vfunc=hidereadw((void*)&Verb[Vrb].vdo);
#else
		vfunc=Verb[Vrb].vdo;
#endif
		(*vfunc) ();
	}
}

