/***************************************************************************
 *
 * Simple CBM I/O printf() Text Replacement for More Efficient code.
 * By Joseph Rose, a.k.a. Harry Potter
 *
 * This library can make small programs even smaller by separating the
 * features of printf() into smaller units if the full functionality of
 * printf() is not needed.  
 *
 * This library replaces putchar()'s functionality with direct kernal
 * calls.  You should also be able to use these functions to write
 * directly to an open file by setting it to listen.
 *
 * I would like to thank Jakub on the cc65 mailing list for commenting not
 * to use printf().
 *
 ***************************************************************************/

#ifndef __cc65_A2SimpleIO__
#define __cc65_A2SimpleIO__

//Prints a null-delimeted string to the screen, up to 256 bytes.
void __fastcall__ prints (char*);

//Same as above, but outputs a CR after the string.
void __fastcall__ printscr (char*);

//Prints a single character.  Directly calls chrout.
void __fastcall__ printc (char);
//Prints a return character.
void __fastcall__ printcr (void);

void __fastcall__ printi (int);

//Prints an unsigned number.
void __fastcall__ printu (unsigned);

//Gets a key-press.
unsigned char __fastcall__ getkey (void);

//Gets a line from the user into In and returns the length.
unsigned char __fastcall__ getline (char* In);

void home(void);
extern unsigned char tabx;
#pragma zpsym ("tabx")

//Turn reverse video on or off.
void reverson  (void);
void reversoff (void);
//Flasing mode.
void flash(void);

#endif
