/***********************************************************************
 * 
 * Contains messages this program displays.
 *
 ***********************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>

#include "simpleio.h"

//Put data in extended memory if desired.
#ifdef __USEFARMEM__
#ifdef __C128__
#pragma data-name ("B1DATA")
#pragma rodata-name ("B1RODATA")
#elif defined __C64__
#pragma data-name ("HIDEDATA")
#pragma rodata-name ("HIDECONST")
#elif defined __ATARIXL__
#pragma data-name ("AUXDATA")
#pragma rodata-name ("AUXRO")
#elif defined __PLUS4__
#pragma data-name ("B1DATA")
#pragma rodata-name ("B1RODATA")
#elif defined __APPLE2ENH__
#pragma data-name ("AUXRW")
#pragma rodata-name ("AUXRO")
#endif
#endif

#if defined __APPLE2ENH__
#pragma charmap (10, 13)
#endif
//Instructions on how to play the game.
//Displayed when the user types "intro."
//Currently only supports two pages.  If you
//want more, add to the vIntro() function in
//Words.c.
const char* HelpPages[2] =
{
	"\nPlace instruction page 1 here.\n\n"
	"Press X to exit or any other key to\ncontinue\n"
,
	"\nPlace instruction page 2 here.\n\n"

};

