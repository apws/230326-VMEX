#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>

#include <c64.h>

#include "c64hide.h"

extern unsigned _HIMEM__;
char filename[]="auxdata,s";
int hideloadfile2 (void)
{
	static unsigned i;
	//static unsigned char c;
	/*static*/ unsigned char* a=&_HIMEM__;
	//a=0xD000;
	//i=cbm_open (3,8,CBM_READ,"auxdata,s");
	__asm__ (
		"\tlda\t#3\n"
		"\tldx\t#8\n"
		"\tldy\t#0\n"
		"\tjsr\tSETLFS\n"
		"\tlda\t#9\n"
		"\tldx\t#<_filename\n"
		"\tldy\t#>_filename\n"
		"\tjsr\tSETNAM\n"
		"\tjsr\tOPEN\n"
		);
	//puts ("About to load file...."); cgetc();
	//if (i!=0) {printf ("Error #%d loading file.\n",i); cgetc();}
	cbm_k_chkin (3);
	//for (i=0; !cbm_k_readst(); ++i)
	while (!cbm_k_readst())
	{
		//if (cbm_read (3,&c,1)<=0) break;
		//cbm_read (3,&c,1);
		hidewriteb (a++, cbm_k_basin()); 
		//hidewriteb (a++, c);
		//*((char*)a++)=c;
		//*((char*)1024)=c;
		//if (a>=1040) break;
		//putchar (c);
	}
	cbm_k_clrch();
	cbm_close(3);
	return 0;
}

