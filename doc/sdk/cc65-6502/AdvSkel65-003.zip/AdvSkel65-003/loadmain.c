/***********************************************************************
 * 
 * Individual module for the cc65 compiler.
 *
 * The template for this file was created by TempC Module Creator by
 * Joseph Rose.  This template can be used in your programs, provided
 * you mention TempC in your software's documentation.  If this source
 * code is distributed, this copyright must be included in the file.
 *
 ***********************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include "pd_disk.h"
#include "a2simpleio.h"

unsigned char loadstub (char* filename, void* buffer)
{
	//void* mem;
	unsigned i, k;
	unsigned char j, h;
	//FILE* f=fopen(filename, "rb");
//printu(PD_OPEN (filename, &h)&255);
// printf ("0x%X:\r\r", &_AUXRO_LOAD__);
// cgetc ();
	PD_OPEN (filename, &h);
	PD_READ (h, buffer, -1, &k);
//printc ('.');
	PD_CLOSE (h);
}


