/***********************************************************************
 * 
 * Individual module for the cc65 compiler.
 *
 * The template for this file was created by TempC Module Creator by
 * Joseph Rose.  This template can be used in your programs, provided
 * you mention TempC in your software's documentation.  If this source
 * code is distributed, this copyright must be included in the file.
 *
 ***********************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include "pd_disk.h"
#include "a2simpleio.h"

char __fastcall__ aux_readbyte (char*);
void __fastcall__ aux_writebyte (char*, unsigned char);
unsigned __fastcall__ aux_strlen (char*);
void __fastcall__ aux_memcpyfrom (void*, void*, unsigned);
void __fastcall__ aux_memcpyto (void*, void*, unsigned);
void __fastcall__ aux_print (void*);
extern unsigned _AUXRO_LOAD__;
static unsigned char buffer[32];
unsigned char loadauxro (char* filename)
{
	//void* mem;
	unsigned i, k;
	unsigned char j, h;
	//FILE* f=fopen(filename, "rb");
	PD_OPEN (filename, &h);
// printf ("0x%X:\r\r", &_AUXRO_LOAD__);
// cgetc ();
	for (i=0x800; ; i+=k) {
		//j=fread (buffer, 1, 32, f);
		j=PD_READ (h, &buffer, 32, &k);
//memcpy (0x400, buffer, 17); getkey();
//printcr(); printu (k);
		if (j) break;
		//if (j==0) break;
		aux_memcpyto (i, &buffer, k);
		//if (j<32) break;
	} //fclose (f);
	PD_CLOSE (h);
//aux_print (0x800);
//aux_memcpyfrom (0x400, 0x800, 17); getkey();
}


