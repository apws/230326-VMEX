
/***********************************************************************
 * 
 * Individual module for the cc65 compiler.
 *
 * The template for this file was created by TempC Module Creator by
 * Joseph Rose.  This template can be used in your programs, provided
 * you mention TempC in your software's documentation.  If this source
 * code is distributed, this copyright must be included in the file.
 *
 ***********************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#include <conio.h>

#include <cbm.h>
#include "simpleio.h"
#include "membankp4.h"



unsigned __fastcall__ bank1_cbm_read (unsigned char lfn, void* buffer, unsigned size)
/* Reads up to "size" bytes from a file to "buffer".
 * Returns the number of actually read bytes, 0 if there are no bytes left
 * (EOF) or -1 in case of an error. _oserror contains an errorcode then (see
 * table below).
 */
{
	static unsigned int bytesread;
	unsigned char tmp, *a=buffer;

	/* if we can't change to the inputchannel #lfn then return an error */
	if (_oserror = cbm_k_chkin(lfn)) return -1;

	bytesread = 0;
	while (bytesread<size && !cbm_k_readst()) {
		tmp = cbm_k_basin();
		/* the kernal routine BASIN sets ST to EOF if the end of file
		* is reached the first time, then we have store tmp.
		* every subsequent call returns EOF and READ ERROR in ST, then
		* we have to exit the loop here immidiatly. */
		if (cbm_k_readst() & 0xBF) break;
//++*(unsigned char*)0xC00;
		//((unsigned char*)buffer)[bytesread++] = tmp;
		//bank1_writebyte (((unsigned char*)buffer)[bytesread++], tmp);
		bank1_writebyte (a, tmp);
// if ((bank1_readbyte(a)&255)!=tmp)
// {cbm_k_clrch(); printscr ("Error loading Hannes mem."); printu(bytesread); getkey(); break;}
//if (bytesread<0x200) *(unsigned char*)(0xC00+bytesread)=tmp;
		++bytesread; ++a;
//home(); printu (bytesread);
//++brdrcol;
	}
	cbm_k_clrch();
//putchar ('-'); cgetc();
	return bytesread;
}
