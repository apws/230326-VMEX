
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <errno.h>

#include "player.h"
#include "words.h"
#include "rooms.h"
#include "stores.h"


unsigned char StoreNum=-1;

struct Store Store [] =
{
	{
		pMalgon, rMalgonSupplies,
		{
			{iMapLocal,	   49}, 
			{iMetalScanner,	  898}, 
			{iEnergyScanner, 1298},
			{iMedicalScanner,1298},
			{-1}
		}
	}
};


