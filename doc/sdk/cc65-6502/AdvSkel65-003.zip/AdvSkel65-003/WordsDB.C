/**************************************************
 *
 *   Contains the noun and verb data for your text
 *   adventures.
 *
 **************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <errno.h>
#include <ctype.h>

#include "aconst.h"
#include "words.h"
#include "stores.h"
#include "rooms.h"
#include "player.h"
#include "input.h"

//Put this data in extended memory if chosen.
#ifdef __USEFARMEM__
#ifdef __C128__
#pragma data-name ("B1DATA")
#pragma rodata-name ("B1RODATA")
#elif defined __C64__
#pragma data-name ("HIDEDATA")
#pragma rodata-name ("HIDECONST")
#elif defined __ATARIXL__
#pragma data-name ("AUXDATA")
#pragma rodata-name ("AUXRO")
#elif defined __PLUS4__
#pragma data-name ("B1DATA")
#pragma rodata-name ("B1RODATA")
#elif defined __APPLE2ENH__
#pragma data-name ("AUXRW")
#pragma rodata-name ("AUXRO")
#endif
#endif

#pragma local-strings (on)
#ifdef __C128__
#pragma data-name ("TAPEDATA")
#pragma rodata-name ("BSTACKCODE")
#endif

//Nouns:
//Declaration in words.h.
struct item_ Item []={
/* Item 0 */
	{"key",						//Name of item.
		itemAStateChangable | itemAMovable,	//Item attributes,
							//see words.h.
		"Description of key."}			//Description of item.
							//Printed when player types
							//"look item."
							//Make 0 for no help.
};

//Item categories.
//For each entry, start with the name, then continue with up to 6 items
//in the form of the item's #.  If <6 items, end with -1.
struct ItemCate ItemCate []=
{
	{"map",
		{-1}},
};

//Synonyms for other items.
//Start each entry with the name, then follow with the item #.
struct item_Alias ItemAlias []=
{
};

//Vaerbs.  Each entry starts with the name then adds the address of the
//verb handler.
#if defined __C128__
#pragma rodata-name ("TAPECODE")
#endif
struct verb_ Verb[] ={
	{"look",	&vLook},
	{"go",		&vGo},

	{"get",		&vGet},
	{"grab",	&vGet},
	{"take",	&vGet},
	{"put",		&vPut},
	{"place",	&vPut},
	{"drop",	&vPut},
	{"inventory",	&vItems},
	{"i",		&vItems},

	{"intro",	&vIntro},
	{"help",	&vHelp},
	{"read",	&vRead},

	{"n",		&vGoNorth},
	{"s",		&vGoSouth},
	{"e",		&vGoEast},
	{"w",		&vGoWest}
};

