#ifndef __AppleProDOS_DISK_H
#define __AppleProDOS_DISK_H

extern struct PD_fileinfo {
	unsigned char	access;
	unsigned char	type;
	unsigned 	aux;
	unsigned char	store;
	unsigned	used;
	unsigned	datemod;
	unsigned	timemod;
	unsigned	datecreate;
	unsigned	timecreate;

} testfileinfo;
unsigned char __fastcall__ PD_CREATE		(char* file);
unsigned char __fastcall__ PD_CREATEPATH	(char* file);
unsigned char __fastcall__ PD_RENAME		(char* old, char* new);
unsigned char __fastcall__ PD_GETFILEINFO	(char* file, struct PD_fileinfo*);
unsigned char __cdecl__  PD_OPEN		(char* file, unsigned char* handle);
//unsigned char		   PD_OPEN		(char* file, unsigned char* handle);
unsigned char __fastcall__ PD_CLOSE		(char h);

unsigned char __fastcall__ PD_READ		(char h, char* buffer, unsigned size, unsigned* sizeread);
unsigned char __fastcall__ PD_WRITE		(char h, char* buffer, unsigned size, unsigned* sizeread);
unsigned char __fastcall__ PD_SETPOS		(char h, unsigned long ptr);
unsigned char __fastcall__ PD_GETPOS		(char h, unsigned long* ptr);

#endif

